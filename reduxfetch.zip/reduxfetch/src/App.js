import React, { Component } from 'react';
import './App.css';
import { connect } from 'react-redux'
import { fetchData } from './action'
import "bootstrap/dist/css/bootstrap.min.css";
// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }
class App extends Component {

  componentDidMount() {
    this.props.onFetchData();
    console.log(this.props.data);
  }

  render() {
    return (
      <div className="App">
        <h1>Fetching the data from the backend</h1>
        {this.props.error && <p>{this.props.error}</p>}

        {this.props.data && <ul class="list-group">
         
          {this.props.data.map((number)=>
          {
          return <li class="list-group-item d-flex justify-content-between align-items-start">
          <div class="ms-2 me-auto">
            <div class="fw-bold">{number.first_name} {number.last_name}</div>
            {number.email} 
            
          </div>
          <span class="badge"><img src={number.avatar} alt="avtar"/></span>
          {/* <span class="badge bg-primary rounded-pill">14</span> */}
        </li>;
        // <li class="list-group-item d-flex justify-content-between align-items-center">id: {number.id} {number.email}</li>;
            
          })}
        </ul>}
      </div>
    );
  }
}


const mapStatetoProps = (state) => {
  return { num: state.num, data: state.data, error: state.error }
}

const mapDispatchprops = (dispatch) => {
  return { onFetchData: () => dispatch(fetchData()) }
}


export default connect(mapStatetoProps, mapDispatchprops)(App);

// export default App;
